Bootstrap 4 Template For Startups

Theme name:
=======================================================================
Tempo

Theme version:
=======================================================================
v4.0

Release Date:
=======================================================================
21 March 2019

Author: 
=======================================================================
Xiaoying Riley at 3rd Wave Media

Contact:
=======================================================================
Web: http://themes.3rdwavemedia.com/
Email: themes@3rdwavemedia.com
Facebook: https://www.facebook.com/3rdwavethemes/
Twitter: 3rdwave_themes

